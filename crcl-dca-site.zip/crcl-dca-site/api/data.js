// api/data.js — Vercel Serverless Function
// 聚合5个数据源，返回 CRCL DCA 评分所需全部数据
// 部署后访问: /api/data

export default async function handler(req, res) {
  res.setHeader('Cache-Control', 's-maxage=300, stale-while-revalidate=600');
  res.setHeader('Access-Control-Allow-Origin', '*');

  try {
    // ── 并行拉取所有数据源 ──
    const [crclRes, vixRes, usdcRes, fgiRes] = await Promise.allSettled([
      fetch('https://query1.finance.yahoo.com/v8/finance/chart/CRCL?range=1y&interval=1d&includePrePost=false'),
      fetch('https://query1.finance.yahoo.com/v8/finance/chart/%5EVIX?range=5d&interval=1d'),
      fetch('https://stablecoins.llama.fi/stablecoin/1'),  // USDC = id 1
      fetch('https://api.alternative.me/fgi/?limit=1'),
    ]);

    const result = {
      updated: new Date().toISOString().slice(0, 10),
      sources: {},
      errors: [],
    };

    // ── 1. CRCL 股价 + 技术指标 ──
    if (crclRes.status === 'fulfilled' && crclRes.value.ok) {
      const json = await crclRes.value.json();
      const chart = json?.chart?.result?.[0];
      if (chart) {
        const meta = chart.meta;
        const closes = chart.indicators?.quote?.[0]?.close?.filter(v => v != null) || [];
        const price = meta.regularMarketPrice;
        const prevClose = meta.previousClose || meta.chartPreviousClose;

        // 200日均线 & 50日均线
        const ma200 = closes.length >= 200
          ? +(closes.slice(-200).reduce((a, b) => a + b, 0) / 200).toFixed(2)
          : null;
        const ma50 = closes.length >= 50
          ? +(closes.slice(-50).reduce((a, b) => a + b, 0) / 50).toFixed(2)
          : null;

        // RSI(14)
        const rsi14 = calcRSI(closes, 14);

        // 布林带位置 (20日, 2σ)
        const bbPos = calcBBPosition(closes, 20, 2);

        // MACD
        const macdSig = calcMACDSignal(closes);

        result.price = +price.toFixed(2);
        result.priceChg = prevClose ? +((price - prevClose) / prevClose * 100).toFixed(2) : 0;
        result.ma200 = ma200;
        result.ma50 = ma50;
        result.rsi14 = rsi14 != null ? +rsi14.toFixed(1) : null;
        result.bbPos = bbPos != null ? +bbPos.toFixed(2) : null;
        result.macdSig = macdSig;
        result.sources.crcl = 'yahoo_finance';

        // PS ratio — 用 Yahoo Finance 的 summaryDetail
        // chart API 没有 PS, 需要额外请求
        try {
          const summaryRes = await fetch(
            `https://query1.finance.yahoo.com/v10/finance/quoteSummary/CRCL?modules=summaryDetail,defaultKeyStatistics`
          );
          if (summaryRes.ok) {
            const sJson = await summaryRes.json();
            const stats = sJson?.quoteSummary?.result?.[0]?.defaultKeyStatistics;
            const detail = sJson?.quoteSummary?.result?.[0]?.summaryDetail;
            result.ps = stats?.priceToSalesTrailing12Months?.raw
              ? +stats.priceToSalesTrailing12Months.raw.toFixed(2)
              : null;
            result.pe = detail?.trailingPE?.raw
              ? +detail.trailingPE.raw.toFixed(2)
              : null;
          }
        } catch (e) {
          result.errors.push('ps_ratio_fetch_failed');
        }
      }
    } else {
      result.errors.push('crcl_price_fetch_failed');
    }

    // ── 2. VIX ──
    if (vixRes.status === 'fulfilled' && vixRes.value.ok) {
      const json = await vixRes.value.json();
      const vixPrice = json?.chart?.result?.[0]?.meta?.regularMarketPrice;
      result.vix = vixPrice ? +vixPrice.toFixed(1) : null;
      result.sources.vix = 'yahoo_finance';
    } else {
      result.errors.push('vix_fetch_failed');
    }

    // ── 3. USDC Supply (DefiLlama) ──
    if (usdcRes.status === 'fulfilled' && usdcRes.value.ok) {
      const json = await usdcRes.value.json();
      // DefiLlama returns circulating supply in the 'gecko_id' = 'usd-coin' chain data
      const currentSupply = json?.currentChainBalances;
      const totalCirculating = json?.circulatingAmount?.peggedUSD;

      if (totalCirculating) {
        result.usdcSupply = +(totalCirculating / 1e9).toFixed(2); // Convert to billions

        // 计算30天前的供应量
        const chains = json?.chainBalances;
        if (chains) {
          const allTokens = Object.values(chains);
          // Get total supply from 30 days ago
          const now = Date.now() / 1000;
          const thirtyDaysAgo = now - 30 * 86400;

          // Try to find historical data from tokens array
          let supply30d = null;
          for (const chain of allTokens) {
            const tokens = chain?.tokens;
            if (tokens && tokens.length > 0) {
              // tokens are sorted by date, find closest to 30 days ago
              const closest = tokens.reduce((prev, curr) =>
                Math.abs(curr.date - thirtyDaysAgo) < Math.abs(prev.date - thirtyDaysAgo) ? curr : prev
              );
              if (closest && Math.abs(closest.date - thirtyDaysAgo) < 5 * 86400) {
                supply30d = (supply30d || 0) + (closest.circulating?.peggedUSD || 0);
              }
            }
          }
          if (supply30d) {
            result.usdc30d = +(supply30d / 1e9).toFixed(2);
          }
        }

        // YoY: 尝试从历史数据计算
        result.sources.usdc = 'defillama';
      }
    } else {
      result.errors.push('usdc_fetch_failed');
    }

    // ── 4. Crypto Fear & Greed ──
    if (fgiRes.status === 'fulfilled' && fgiRes.value.ok) {
      const json = await fgiRes.value.json();
      const fgiValue = json?.data?.[0]?.value;
      result.cfg = fgiValue ? parseInt(fgiValue) : null;
      result.sources.fgi = 'alternative_me';
    } else {
      result.errors.push('fgi_fetch_failed');
    }

    // ── 5. 联邦基金利率 (hardcoded, 需要 FRED API key 才能自动化) ──
    // FRED API: https://api.stlouisfed.org/fred/series/observations?series_id=FEDFUNDS&api_key=YOUR_KEY
    // 用户可以设置环境变量 FRED_API_KEY 来启用自动获取
    if (process.env.FRED_API_KEY) {
      try {
        const fredRes = await fetch(
          `https://api.stlouisfed.org/fred/series/observations?series_id=FEDFUNDS&limit=2&sort_order=desc&api_key=${process.env.FRED_API_KEY}&file_type=json`
        );
        if (fredRes.ok) {
          const fredJson = await fredRes.json();
          const obs = fredJson?.observations;
          if (obs && obs.length > 0) {
            result.ffr = +parseFloat(obs[0].value).toFixed(2);
            if (obs.length > 1) {
              const prev = parseFloat(obs[1].value);
              const curr = parseFloat(obs[0].value);
              result.ffrTrend = curr > prev ? 'rising' : curr < prev ? 'falling' : 'stable';
            }
            result.sources.ffr = 'fred';
          }
        }
      } catch (e) {
        result.errors.push('fred_fetch_failed');
      }
    }

    // ── 6. 2年期美债收益率 ──
    try {
      const t2yRes = await fetch('https://query1.finance.yahoo.com/v8/finance/chart/%5EIRX?range=5d&interval=1d');
      if (t2yRes.ok) {
        // ^IRX is 13-week T-bill, use ^TNX for 10y or estimate 2y
        // Actually let's try to get 2Y directly
        const t2yRes2 = await fetch('https://query1.finance.yahoo.com/v8/finance/chart/2YY%3DF?range=5d&interval=1d');
        if (t2yRes2.ok) {
          const t2yJson = await t2yRes2.json();
          const t2yPrice = t2yJson?.chart?.result?.[0]?.meta?.regularMarketPrice;
          if (t2yPrice) result.t2y = +t2yPrice.toFixed(2);
        }
      }
    } catch (e) {
      // Non-critical, ignore
    }

    return res.status(200).json(result);

  } catch (error) {
    return res.status(500).json({
      error: 'Internal server error',
      message: error.message,
    });
  }
}

// ── 技术指标计算函数 ──

function calcRSI(closes, period = 14) {
  if (closes.length < period + 1) return null;
  const recent = closes.slice(-(period + 1));
  let gains = 0, losses = 0;
  for (let i = 1; i < recent.length; i++) {
    const diff = recent[i] - recent[i - 1];
    if (diff > 0) gains += diff;
    else losses -= diff;
  }
  const avgGain = gains / period;
  const avgLoss = losses / period;
  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return 100 - (100 / (1 + rs));
}

function calcBBPosition(closes, period = 20, mult = 2) {
  if (closes.length < period) return null;
  const recent = closes.slice(-period);
  const sma = recent.reduce((a, b) => a + b, 0) / period;
  const variance = recent.reduce((sum, v) => sum + Math.pow(v - sma, 2), 0) / period;
  const std = Math.sqrt(variance);
  const upper = sma + mult * std;
  const lower = sma - mult * std;
  const current = closes[closes.length - 1];
  if (upper === lower) return 0.5;
  return Math.max(0, Math.min(1, (current - lower) / (upper - lower)));
}

function calcMACDSignal(closes) {
  if (closes.length < 35) return 'bullish'; // not enough data
  const ema12 = calcEMA(closes, 12);
  const ema26 = calcEMA(closes, 26);
  if (ema12 == null || ema26 == null) return 'bullish';
  const macdLine = ema12 - ema26;

  // Simplified: if MACD line > 0, bullish
  // For proper signal line, we'd need MACD history
  const prevEma12 = calcEMA(closes.slice(0, -1), 12);
  const prevEma26 = calcEMA(closes.slice(0, -1), 26);
  const prevMacd = (prevEma12 || 0) - (prevEma26 || 0);

  // Bullish if MACD is rising or positive
  return macdLine > prevMacd ? 'bullish' : 'bearish';
}

function calcEMA(data, period) {
  if (data.length < period) return null;
  const k = 2 / (period + 1);
  let ema = data.slice(0, period).reduce((a, b) => a + b, 0) / period;
  for (let i = period; i < data.length; i++) {
    ema = data[i] * k + ema * (1 - k);
  }
  return ema;
}
