// ── CRCL DCA Scoring Engine v3.1 ──

export function sVal(d) {
  const dev = (d.price - d.ma200) / d.ma200;
  let ma = dev <= -0.3 ? 95 : dev <= 0 ? 50 + (-dev / 0.3) * 45 : dev <= 0.5 ? 50 - (dev / 0.5) * 45 : 5;
  return Math.round(ma * 0.6 + (100 - d.psPct) * 0.4);
}

export function sUsdc(d) {
  const g = ((d.usdcSupply - d.usdc30d) / d.usdc30d) * 100;
  let gs = g >= 3 ? 90 : g >= 1 ? 50 + ((g - 1) / 2) * 40 : g >= 0 ? 30 + g * 20 : Math.max(10, 30 + g * 10);
  let yb = d.usdcYoY >= 50 ? 15 : d.usdcYoY >= 30 ? 10 : d.usdcYoY >= 10 ? 5 : 0;
  return Math.min(100, Math.round(gs * 0.7 + (50 + yb) * 0.3));
}

export function sRate(d) {
  let r = d.ffr >= 3.5 && d.ffr <= 5 ? 75 : d.ffr >= 2.5 ? 55 : d.ffr >= 1.5 ? 35 : 20;
  let t = d.ffrTrend === 'stable' ? 10 : d.ffrTrend === 'falling' ? -5 : 5;
  return Math.min(100, Math.max(0, r + t));
}

export function sTech(d) {
  let rsi = d.rsi14 <= 20 ? 95 : d.rsi14 <= 30 ? 80 : d.rsi14 <= 50 ? 50 + ((50 - d.rsi14) / 20) * 30 : d.rsi14 <= 70 ? 50 - ((d.rsi14 - 50) / 20) * 30 : 15;
  return Math.round(rsi * 0.5 + (100 - d.bbPos * 80) * 0.3 + (d.macdSig === 'bullish' ? 60 : 40) * 0.2);
}

export function sSent(d) {
  let v = d.vix >= 35 ? 95 : d.vix >= 25 ? 60 + ((d.vix - 25) / 10) * 35 : d.vix >= 15 ? 40 + ((d.vix - 15) / 10) * 20 : 20;
  return Math.round(v * 0.5 + (100 - d.cfg) * 0.5);
}

export function toMult(s) {
  if (s <= 30) return +(0.1 + (s / 30) * 0.2).toFixed(2);
  if (s <= 50) return +(0.3 + ((s - 30) / 20) * 0.5).toFixed(2);
  if (s <= 70) return +(0.8 + ((s - 50) / 20) * 0.4).toFixed(2);
  if (s <= 85) return +(1.2 + ((s - 70) / 15) * 0.8).toFixed(2);
  return +(2.0 + ((s - 85) / 15) * 1.0).toFixed(2);
}

export function labelOf(s) {
  return s >= 85 ? '极度低估' : s >= 70 ? '偏低估' : s >= 50 ? '合理估值' : s >= 30 ? '偏高估' : '高估区间';
}

export function calcComposite(dims, pulse = 0) {
  return Math.min(100, Math.max(0, Math.round(
    dims.val.score * 0.3 + dims.usdc.score * 0.25 + dims.rate.score * 0.2 +
    dims.tech.score * 0.15 + dims.sent.score * 0.1
  ) + pulse));
}

export function calcRisk(price, costBasis, positionPct, totalAssets, mult, base) {
  const drawdown = costBasis > 0 ? ((price - costBasis) / costBasis) * 100 : 0;
  const weeklyMax = base * 3;
  const todayAmt = Math.round(base * mult);
  const alerts = [];
  if (drawdown <= -30) alerts.push({ level: '🔴', msg: `回撤 ${drawdown.toFixed(1)}% ≥30%，触发熔断`, action: 'halt' });
  else if (drawdown <= -20) alerts.push({ level: '🟠', msg: `回撤 ${drawdown.toFixed(1)}%，接近熔断线` });
  if (positionPct >= 20) alerts.push({ level: '🔴', msg: `仓位 ${positionPct.toFixed(1)}% ≥20%上限`, action: 'halt' });
  else if (positionPct >= 15) alerts.push({ level: '🟠', msg: `仓位 ${positionPct.toFixed(1)}%，接近上限` });
  const halted = alerts.some(a => a.action === 'halt');
  return { drawdown, weeklyMax, alerts, halted, todayAmt: halted ? 0 : todayAmt };
}

export function buildDims(data) {
  return {
    val: { score: sVal(data), name: '估值偏离', en: 'Valuation', w: 30, raw: `偏离 ${(((data.price - data.ma200) / data.ma200) * 100).toFixed(1)}%`, desc: `股价vs200日均线+PS历史百分位。PS=${data.ps}，历史${data.psPct}%分位。` },
    usdc: { score: sUsdc(data), name: 'USDC生态', en: 'USDC Supply', w: 25, raw: `$${data.usdcSupply}B`, desc: `USDC=$${data.usdcSupply}B，30日+${(((data.usdcSupply - data.usdc30d) / data.usdc30d) * 100).toFixed(1)}%，YoY+${data.usdcYoY}%。` },
    rate: { score: sRate(data), name: '利率环境', en: 'Rate Env', w: 20, raw: `FFR ${data.ffr}%`, desc: `FFR ${data.ffr}%${data.ffrTrend === 'stable' ? '稳定' : data.ffrTrend === 'falling' ? '下行' : '上行'}。3.5-5%最优区间。` },
    tech: { score: sTech(data), name: '技术面', en: 'Technical', w: 15, raw: `RSI ${data.rsi14}`, desc: `RSI=${data.rsi14}，布林带${(data.bbPos * 100).toFixed(0)}%，MACD${data.macdSig === 'bullish' ? '多头' : '空头'}。` },
    sent: { score: sSent(data), name: '市场情绪', en: 'Sentiment', w: 10, raw: `VIX ${data.vix}`, desc: `VIX=${data.vix}，加密F&G=${data.cfg}/100。两个都恐惧=最佳买入。` },
  };
}
